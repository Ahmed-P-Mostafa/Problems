package com.company;

public class Main {

    public static void main(String[] args) {
        Student studnt = new Student("ahmed");
        System.out.println(studnt.getName());


    }
}
