package com.company;

public class RandomWord {
    public static void main(String[] args) {
        
    }
}
